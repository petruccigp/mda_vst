To create vst bundle files simply execute the included "makeall.sh" script from the terminal. This will execute the makefile, do the archiving and generate the files inside this folder. All intermediate files are cleaned up afterwards.


