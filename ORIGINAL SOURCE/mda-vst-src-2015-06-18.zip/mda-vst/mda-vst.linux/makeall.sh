#!/bin/sh

echo Compiling Started.

make clean all cleanobj

echo All Done.
